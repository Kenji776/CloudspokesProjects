chatterPhoto allows users to easily attach content via chatter posts to contacts in your org.

1) Install the class into your org by copying and pasting the contents of the file, or using the package
2) Create an email service. Link it to the chatterPhoto class. Set security as desired.
3) Create an email address for the service.
4) Send a test email to the service. Include a contact name (firstname space lastname format) in the subject line. Include a description and attach the content to post to chatter. You may include multiple attachments.
5) Send the email and await confirmation.

Package install URL: https://login.salesforce.com/packaging/installPackage.apexp?p0=04tE0000000Pcwc
Video URL: http://screencast.com/t/zOcfW0S3q