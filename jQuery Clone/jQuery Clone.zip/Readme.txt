jQuery Clone and Configure Records
By: Kenji776

Unmanaged Package link: https://login.salesforce.com/packaging/installPackage.apexp?p0=04tE0000000Pd1S
Video Link: http://www.screencast.com/t/Jh3hPHjpvYz

1) Install the pacakge
2) Over ride edit link on package object if desired
3) Add copy package custom button.

that should be it. It should run from there.


embed video code

<!-- copy and paste. Modify height and width if desired. --> <object id="scPlayer"  width="1920" height="995" type="application/x-shockwave-flash" data="http://content.screencast.com/users/Kenji776/folders/Jing/media/13d41846-b6b3-47b2-9260-a029ef2ac74e/jingswfplayer.swf" > <param name="movie" value="http://content.screencast.com/users/Kenji776/folders/Jing/media/13d41846-b6b3-47b2-9260-a029ef2ac74e/jingswfplayer.swf" /> <param name="quality" value="high" /> <param name="bgcolor" value="#FFFFFF" /> <param name="flashVars" value="thumb=http://content.screencast.com/users/Kenji776/folders/Jing/media/13d41846-b6b3-47b2-9260-a029ef2ac74e/FirstFrame.jpg&containerwidth=1920&containerheight=995&content=http://content.screencast.com/users/Kenji776/folders/Jing/media/13d41846-b6b3-47b2-9260-a029ef2ac74e/jQuery_copy_package.swf&blurover=false" /> <param name="allowFullScreen" value="true" /> <param name="scale" value="showall" /> <param name="allowScriptAccess" value="always" /> <param name="base" value="http://content.screencast.com/users/Kenji776/folders/Jing/media/13d41846-b6b3-47b2-9260-a029ef2ac74e/" /> Unable to display content. Adobe Flash is required.</object>