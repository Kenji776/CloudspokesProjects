View working live example at http://xerointeractive-developer-edition.na9.force.com/partyForce

Demo vid 1: http://xerointeractive.com/Dreamforce_1.swf
Demo vid 2: http://xerointeractive.com/Dreamforce_2.swf

Couldn't get an unmamanged package to upload. Salesforce was bugging out saying I had 0% code coverage, when the test runner said
I had 85%. I think it has something to do with the @remoteAction methods. Not sure. I think I included all resources, let me know
if I forgot anything. 

Make a site, host all the pages and the apex class. Change the URL reference in the component from my org to yours. You may want to change the image references in the email templates to your own as well, and the links in the emails.

I'll keep puzting with the unmanaged package tomorrow and see if I can get it to upload.